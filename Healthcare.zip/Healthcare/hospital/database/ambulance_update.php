<?php
include('../../db_connect/db.php');

	$mdcambid=$_POST["mdcambid"];
	$inchaprsn=$_POST["inchaprsn"];
	$cntn1=$_POST["cntn1"];
	$cntn2=$_POST["cntn2"];
	$addr=$_POST["addr"];
	$location=$_POST["location"];

	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../../admin/ambulance_photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];	
	
if($photo=="")
{
$sql = "update  ambulance set inchaprsn='$inchaprsn',cntn1='$cntn1',cntn2='$cntn2',addr='$addr',location='$location' where amcdcid='$mdcambid'";
$q1 = $db->prepare($sql);
$q1->execute();
}
else
{
$sql = "update  ambulance set inchaprsn='$inchaprsn',cntn1='$cntn1',cntn2='$cntn2',addr='$addr',location='$location',photo='$photo' where amcdcid='$mdcambid'";
$q1 = $db->prepare($sql);
$q1->execute();
}
header("location:../ambulance_edit.php");

?>					

	
