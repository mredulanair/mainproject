<?php
include('../../db_connect/db.php');

	$hostid=$_POST["hostid"];
	$hname=$_POST["hname"];
	$name=$_POST["name"];
	$type=$_POST["type"];
	$roomno=$_POST["roomno"];
	$floor=$_POST["floor"];
	$cont=$_POST["cont"];
	$des=$_POST["des"];
	$rate=$_POST["rate"];
	$date=date("Y-m-d");
	 
$sql = "insert into rooms(hostid,name,type,roomno,floor,cont,des,rate,date,hname) VALUES ('$hostid','$name','$type','$roomno','$floor','$cont','$des','$rate','$date','$hname')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../rooms_search.php");

?>		
	
		
