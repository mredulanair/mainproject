 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; EMERGENCY RESPONSE SYSTEM . 2022-2023  All rights reserved.</strong>
</footer>