<?php
include('../../db_connect/db.php');

	$mdcambid=$_POST["mdcambid"];
	$name=$_POST["name"];
	$inchaprsn=$_POST["inchaprsn"];
	$cntn1=$_POST["cntn1"];
	$cntn2=$_POST["cntn2"];
	$email=$_POST["email"];
	$addr=$_POST["addr"];
	$hother=$_POST["hother"];
	$location=$_POST["location"];
	$date=$_POST["date"];

	$image = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
	$image_name = addslashes($_FILES['photo']['name']);
	$image_size = getimagesize($_FILES['photo']['tmp_name']);
	move_uploaded_file($_FILES["photo"]["tmp_name"], "../ambulance_photo/" . $_FILES["photo"]["name"]);
	$photo = $_FILES["photo"]["name"];	
	
$sql = "insert into ambulance(amcdcid,name,inchaprsn,cntn1,cntn2,email,addr,location,date,photo,hother)VALUES('$mdcambid','$name','$inchaprsn','$cntn1','$cntn2','$email','$addr','$location','$date','$photo','$hother')";
$q1 = $db->prepare($sql);
$q1->execute();

header("location:../ambulance_register.php");

?>					

	
