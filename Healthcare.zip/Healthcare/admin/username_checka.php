<?php  
include('../db_connect/db.php');
if($_POST)
{
	$username1 = $_POST['usernameh'];
	$username2 = strtolower($_POST['usernameh']);
	$username3 = strtoupper($_POST['usernameh']);

	$result = $db->prepare("SELECT * FROM admin WHERE username = '$username1'");
	$result->execute();
	$rowc1 = $result->rowcount();
	
	$result = $db->prepare("SELECT * FROM admin WHERE username = '$username2'");
	$result->execute();
	$rowc2 = $result->rowcount();
	$result = $db->prepare("SELECT * FROM admin WHERE username = '$username3'");
	$result->execute();
	$rowc3 = $result->rowcount();
	if($rowc1 >0 || $rowc2 > 0 || $rowc3 > 0)
	{
	?>
    <span style="color:red;">"<?php echo $_POST['usernameh'] ?>" Already Exist.</span>
	<?php
	}
	else
	{
	?>
    <span style="color:green;">"<?php echo $_POST['usernameh'] ?>" Available.</span>
	<?php
	}

}
?>