  

  <link rel="stylesheet" href="webcraft/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="webcraft/font-awesome/css/font-awesome.min.css">
  
 
  <link rel="stylesheet" href="webcraft/Ionicons/css/ionicons.min.css">

  <link rel="stylesheet" href="webcraft/datatables.net-bs/css/dataTables.bootstrap.min.css">

  <link rel="stylesheet" href="style/css/AdminLTE.min.css">
  <link rel="stylesheet" href="style/css/skins/_all-skins.min.css">

 <link rel="stylesheet" href="webcraft/checkinchekout/datepicker.css" />
