<script src="webcraft/jquery/dist/jquery.min.js"></script>
<script src="webcraft/bootstrap/dist/js/bootstrap.min.js"></script>

<script src="webcraft/fastclick/lib/fastclick.js"></script>
<script src="style/js/adminlte.min.js"></script>

<script src="webcraft/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="webcraft/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="webcraft/datatables.net/js/bootbox.min.js"></script>

<script src="webcraft/js/pages/dashboard2.js"></script>
<script src="webcraft/js/demo.js"></script>

<script src="webcraft/checkinchekout/bootstrap-datepicker.js"></script>
