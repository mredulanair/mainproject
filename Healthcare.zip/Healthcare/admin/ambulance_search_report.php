<?php
 	 require("auth.php");
  	include('../db_connect/db.php');	
    $amblnce=$_POST["amblnce"];
	$result = $db->prepare("select * from  ambulance where name='$amblnce'");
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++)
	{
		$mdcambid=$row["amcdcid"];
		$name=$row["name"];
		$inchaprsn=$row["inchaprsn"];
		$cntn1=$row["cntn1"];
		$cntn2=$row["cntn2"];
		$email=$row["email"];
		$addr=$row["addr"];
		$location=$row["location"];
		$date=$row["date"];
		$photo=$row["photo"];
		$hother=$row["hother"];
	}
?>
<!DOCTYPE html>
<html>

<head>
	<title>Emergency Response System</title>
    <link rel="icon" type="text/css" sizes="16x16" href="../images/logo.png">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

	<?php
	include("include/css.php");
	?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	<header class="main-header">
	<?php
	include("include/header.php");
	?>
	</header>
	<aside class="main-sidebar">
	<?php
	include("include/leftmenu.php");
	?>
	</aside>
	<div class="content-wrapper">
	<?php
	include("include/topmenu.php");
	?>
	</div>
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-12">
              <div class="box box-danger">
                <div class="box-body no-padding">
                	<div class="panel panel-primary">
  					  <div class="panel-heading ">
							Ambulance Details
                        </div>
							<div class="panel-body">  
                            
                            <form method="post" action="database/ambulance_save.php" enctype="multipart/form-data" autocomplete="off">
                            <div class="col-md-6 col-sm-6 col-xs-12 well">
                                
                                <div class="row">
                                
                                        <div class="alert" style="padding:5px; background-color:#3399cc; color:white;">
                                            <strong>Ambulance Information</strong>
                                        </div>
                                    
                                    	<div class="col-md-12 col-sm-12 col-xs-12">
                                            <label>Ambulance ID</label>
                                            <input type="text" class="form-control" name="mdcambid" value="<?php echo $mdcambid; ?>" readonly>
                                        </div>                                                                                
                                          <div class="col-md-6 col-sm-12 col-xs-12">
                                           <label>Name</label>
                                           <input type="text"  name="name"   class="form-control" value="<?php echo $name; ?>" readonly>
                                          </div>
                                          <div class="col-md-6 col-sm-12 col-xs-12">
                                           <label>Driver</label>
                                           <input type="text"  name="inchaprsn"   class="form-control" value="<?php echo $inchaprsn; ?>" readonly>
                                          </div>                                                                                    
                                          <div class="col-md-6 col-sm-12 col-xs-12">
                                           <label>Contact No</label>
                                          	<input type="text"  name="cntn1"   class="form-control" value="<?php echo $cntn1; ?>" readonly>  
                                          </div>
                                          <div class="col-md-6 col-sm-12 col-xs-12">
                                           <label>Contact No</label>
                                           <input type="text"  name="cntn2"   class="form-control" value="<?php echo $cntn2; ?>" readonly>
                                          </div>                                                                                                                   
                                         <div class="col-md-12 col-sm-12 col-xs-12">
                                            <label>Email ID</label>
                                            <input type="email"  name="email"  class="form-control" value="<?php echo $email; ?>" readonly>
                                         </div>                                                                                                                                     				
                                    </div>
                                    
								</div>
                                
                        	<div class="col-md-6 col-sm-6 col-xs-12 well">
                            
                                <div class="row">
                                
                                   <div class="alert" style="padding:5px; background-color:#3399cc; color:white">
                                        <strong>Hospital Or Other Information</strong>
                                    </div>
                                   	 <div class="col-md-12 col-sm-12 col-xs-12">
                                       <label>Address</label>
                                      	<textarea  name="addr" rows="4"   class="form-control" readonly><?php echo $addr;?></textarea>
                                      </div>                                       				
									  <div class="col-md-6 col-sm-6 col-xs-12">
										<label style="float:left">Hospital Or Other</label>
										<input type="text"  name="hother"  class="form-control" value="<?php echo $hother; ?>" readonly >
									</div>	  
                                     <div class="col-md-6 col-sm-6 col-xs-12">
										<label style="float:left">Location</label>
										<input type="text"  name="location"  class="form-control" value="<?php echo $location; ?>" readonly >
									</div>	                                                                                                  
                                     <div class="col-md-6 col-sm-6 col-xs-12">
                                            <label>Photo</label>
                                            	<a href="ambulance_photo/<?php echo $photo;?>" target="_blank" class="btn btn-block btn-danger">Download</a>
                                    </div>
                                     <div class="col-md-6 col-sm-6 col-xs-12">
                                            <label>Date</label>
                                         <input type="text"  name="date"  class="form-control"  value="<?php echo $date; ?>" readonly>
                                    </div>                                                  
                                 </div>
                              
                            </div>
                            
                            <div class="col-md-3 col-sm-6 col-xs-12 well" style="float:right">
                            
                                 <div class="col-md-12 col-sm-6 col-xs-12">
                                 <a  href="ambulance_search.php" class="btn btn-block btn-primary">Back</a>
                            	 </div>
                            </div>
                            
							</form>
                         </div>
					 </div>
                  </div>				
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php
	include("include/footer.php");
?>
<div class="control-sidebar-bg"></div>
</div>
<?php
  include("include/js.php");
?>
</body>
</html>
