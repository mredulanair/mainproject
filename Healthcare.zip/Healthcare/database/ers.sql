-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 13, 2022 at 02:04 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ers`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `typ` text NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `typ`) VALUES
(1, 'ers', 'ers', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `ambulance`
--

CREATE TABLE IF NOT EXISTS `ambulance` (
  `dcid` int(11) NOT NULL AUTO_INCREMENT,
  `amcdcid` text,
  `name` text,
  `inchaprsn` text,
  `cntn1` text,
  `cntn2` text,
  `email` varchar(200) NOT NULL,
  `addr` text,
  `location` text,
  `photo` text,
  `date` text,
  `hother` text NOT NULL,
  `hostid` text NOT NULL,
  PRIMARY KEY (`dcid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ambulance`
--

INSERT INTO `ambulance` (`dcid`, `amcdcid`, `name`, `inchaprsn`, `cntn1`, `cntn2`, `email`, `addr`, `location`, `photo`, `date`, `hother`, `hostid`) VALUES
(1, 'MDCAMB205217706', 'Marymatha', 'Rajan', '8908678908', '8908678901', 'rajan@gmail.com', 'near mercy college', 'mercy', 'banner44.jpg', '2022-02-17', 'welcare', 'MDCHP86954128'),
(2, 'MDCAMB141045523', 'rv', 'manoj', '9087564334', '8976454576', 'rv23@gmail.com', 'kn nagar kannur', 'palakkad', 'a.jpg', '2022-02-26', 'welcare', 'MDCHP86954128');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `hbkid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `pname` text,
  `age` text,
  `sex` text,
  `pcont1` text,
  `dat` text,
  `tm` text,
  `bkid` text,
  `bkname` text,
  `hcntn1` text,
  `date` text,
  `diseases` text,
  `descrp` text,
  `stat` text,
  PRIMARY KEY (`hbkid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`hbkid`, `mdcpatid`, `pname`, `age`, `sex`, `pcont1`, `dat`, `tm`, `bkid`, `bkname`, `hcntn1`, `date`, `diseases`, `descrp`, `stat`) VALUES
(1, '1', 'rajiv', '27', 'Male', '9876543210', '2022-02-17', '13:00', 'MDCDOC32536606', 'alex', '9876543012', '17-02-2022', 'ear pain', 'I have ear pain.', 'Accept'),
(2, 'CITZ48706969', 'abc', '25', 'Male', '6764646464', '2022-02-19', '14:40', 'MDCLB721937429', 'DN', '9087896980', '17-02-2022', 'Diabetes', 'Sugar check', 'Accept'),
(3, 'CITZ48706969', 'abc', '25', 'Male', '6764646464', '2022-02-20', '10:00', 'MDCDOC40272223', 'Anju', '8979076590', '17-02-2022', 'Asthma', 'Breathing prblm', 'pending'),
(4, 'CITZ48706969', 'abc', '25', 'Male', '6764646464', '2022-02-25', '17:00', 'MDCHP31816383', 'Trinity', '9895678091', '17-02-2022', 'Long sight', 'Power check', 'Accept'),
(5, 'CITZ81541908', 'rahul', '21', 'Male', '9037878736', '2022-05-02', '10:00', 'MDCDOC94840419', 'Athira', '9087659080', '26-02-2022', 'red eye', 'Infected by red eye.', 'Accept'),
(6, 'CITZ90757146', 'maya', '23', 'Female', '8945678765', '2022-02-27', '11:00', 'MDCDOC12108187', 'Ram', '8965410765', '26-02-2022', 'power check ', 'power check', 'Accept'),
(7, 'CITZ87888308', 'sanoop', '24', 'Male', '9087656545', '2022-02-04', '13:15', 'MDCDOC32536606', 'alex', '9876543012', '26-02-2022', 'ear pain', 'ear pain', 'Accept'),
(8, 'CITZ87888308', 'sanoop', '24', 'Male', '9087656545', '2022-02-18', '00:00', 'MDCLB721937429', 'DN', '9087896980', '26-02-2022', 'ear pain', 'fguhj', 'Accept');

-- --------------------------------------------------------

--
-- Table structure for table `chatm`
--

CREATE TABLE IF NOT EXISTS `chatm` (
  `cht_id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` text NOT NULL,
  `sname` text NOT NULL,
  `smessage` text NOT NULL,
  `sdatetime` text NOT NULL,
  `sphoto` text NOT NULL,
  `receiver_id` text NOT NULL,
  `rname` text NOT NULL,
  `rmessage` text NOT NULL,
  `rdatetime` text NOT NULL,
  `rphoto` text NOT NULL,
  `chtsr_id` text NOT NULL,
  PRIMARY KEY (`cht_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `chatm`
--

INSERT INTO `chatm` (`cht_id`, `sender_id`, `sname`, `smessage`, `sdatetime`, `sphoto`, `receiver_id`, `rname`, `rmessage`, `rdatetime`, `rphoto`, `chtsr_id`) VALUES
(1, 'MDCHP31816383', '', '', '', '', '1', 'rajiv', 'hai.', '02-17 06:02:52', 'team-1.jpg', '1'),
(2, 'MDCHP31816383', 'Trinity', 'hello.how can i help you?', '02-17 06:02:46', 'c2.jpg', '1', '', '', '', '', 'MDCHP31816383'),
(3, 'MDCDOC32536606', '', '', '', '', '1', 'rajiv', 'kkl', '02-17 06:02:23', 'team-1.jpg', '1'),
(4, 'MDCDOC32536606', '', '', '', '', '1', 'rajiv', 'kkl', '02-17 06:02:25', 'team-1.jpg', '1'),
(5, 'MDCDOC32536606', '', '', '', '', '1', 'rajiv', 'kkl', '02-17 06:02:27', 'team-1.jpg', '1'),
(6, 'MDCHP86954128', '', '', '', '', '1', 'rajiv', 'hai', '02-17 06:02:46', 'team-1.jpg', '1'),
(7, 'MDCHP86954128', 'Welcare', 'hello', '02-17 06:02:43', 'team-3.jpg', '1', '', '', '', '', 'MDCHP86954128'),
(8, 'MDCHP31816383', '', '', '', '', 'CITZ48706969', 'abc', 'hi', '02-17 06:02:11', 'c1.jpg', 'CITZ48706969'),
(9, 'MDCPH541168969', '', '', '', '', 'CITZ48706969', 'abc', 'hellloo', '02-17 07:02:06', 'c1.jpg', 'CITZ48706969'),
(10, 'MDCDOC12108187', '', '', '', '', 'CITZ90757146', 'maya', 'hai', '02-26 06:02:23', 'c1.jpg', 'CITZ90757146'),
(11, 'MDCDOC12108187', 'Ram', 'hello', '02-26 06:02:05', 'c1.jpg', 'CITZ90757146', '', '', '', '', 'MDCDOC12108187'),
(12, 'MDCHP86954128', '', '', '', '', 'CITZ90757146', 'maya', 'i am affected by fever', '02-26 06:02:44', 'c1.jpg', 'CITZ90757146'),
(13, 'MDCHP86954128', '', '', '', '', 'CITZ48706969', 'abc', 'hi', '02-26 08:02:11', 'c1.jpg', 'CITZ48706969'),
(14, 'MDCHP86954128', 'Welcare', 'hi', '02-26 08:02:07', 'team-3.jpg', 'CITZ48706969', '', '', '', '', 'MDCHP86954128');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `dcoid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcdocid` text,
  `mrs` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `qul` text,
  `addr` text,
  `cont` text,
  `email` text,
  `special` text,
  `licen` text,
  `exp` text,
  `jdate` text,
  `bsalary` text,
  `aadharno` text,
  `designa` text,
  `photo1` text,
  `photo2` text,
  `photo3` text,
  `des` text,
  `username` text,
  `password` text,
  `hname` text,
  `stat` text,
  `utyp` text,
  PRIMARY KEY (`dcoid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`dcoid`, `mdcdocid`, `mrs`, `name`, `sex`, `dob`, `age`, `qul`, `addr`, `cont`, `email`, `special`, `licen`, `exp`, `jdate`, `bsalary`, `aadharno`, `designa`, `photo1`, `photo2`, `photo3`, `des`, `username`, `password`, `hname`, `stat`, `utyp`) VALUES
(1, 'MDCDOC32536606', 'Mr', 'alex', 'Male', '1990-12-10', '32', 'mbbs,md', 'palakkad', '9876543012', 'alex@gmail.com', 'ENT', 'ent123', '3', '2022-02-17', '3LPA', '1233 9876 0549', 'Cheif', 'c1.jpg', 'c2.jpg', 'team-2.jpg', 'hi', 'alex123', 'alex123', 'Welcare', 'active', 'doctor'),
(2, 'MDCDOC40272223', 'Mrs', 'Anju', 'Female', '1980-02-12', '42', 'MBBS,CDS', 'Mercy', '8979076590', 'anju42@gmail.com', 'cardiologist', 'DR10304', '8years', '2022-02-17', '13lpa', '6103 4560 2109', 'Chief ', 'c2.jpg', 't1.jpg', 'team-1.jpg', 'hai', 'anju123', 'anju123', 'Welcare', 'active', 'doctor'),
(3, 'MDCDOC12108187', 'Mr', 'Ram', 'Male', '1982-05-12', '40', 'MBBS,MS', 'Koppam', '8965410765', 'ram@gmail.com', 'eye specialist', 'DR10234', '9yrs', '2022-02-17', '18lpa', '7890 3444 5687', 'surgeon', 'c1.jpg', 't2.jpg', 't3.jpg', 'Hai.', 'ram123', 'ram123', 'Trinity', 'active', 'doctor'),
(4, 'MDCDOC94840419', 'Mrs', 'Athira', 'Female', '1986-07-17', '36', 'MBBS,OD', 'palakkad', '9087659080', 'athira123@gmail.com', 'optometry', 'Dr10236', '7yrs', '2022-02-17', '10lpa', '5670 5431 6709', 'opthamologist', 'team-3.jpg', 'g2.jpg', 'c3.jpg', 'Hai.', 'athira123', 'athira123', 'Trinity', 'active', 'doctor');

-- --------------------------------------------------------

--
-- Table structure for table `doctoramount`
--

CREATE TABLE IF NOT EXISTS `doctoramount` (
  `dmtpid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `hdname` text,
  `docname` text,
  `diseas` text,
  `cdate` text,
  `diseasdesc` text,
  `prescriptn` text,
  `amount` text,
  `date` date DEFAULT NULL,
  `doctor` text,
  PRIMARY KEY (`dmtpid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `doctoramount`
--

INSERT INTO `doctoramount` (`dmtpid`, `mdcpatid`, `name`, `sex`, `dob`, `age`, `cont1`, `blgrp`, `hdname`, `docname`, `diseas`, `cdate`, `diseasdesc`, `prescriptn`, `amount`, `date`, `doctor`) VALUES
(1, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'alex', 'cold', '2022-02-17', 'sss', 'dsgsdg', '700', '2022-02-17', 'alex'),
(2, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'alex', 'cold', '2022-02-17', 'sss', 'dsgsdg', '300', '2022-02-20', 'alex'),
(3, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'Ram', 'viral fever', '2022-02-17', 'fever at 100degree celsius', 'paracetamol-1 0 1', '250', '2022-02-13', 'Anju'),
(4, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'Ram', 'viral fever', '2022-02-17', 'fever at 100degree celsius', 'paracetamol-1 0 1', '350', '2022-02-14', 'Anju'),
(5, 'CITZ90757146', 'maya', 'Female', '1999-02-12', '23', '8945678765', 'A+', 'Welcare', 'Ram', 'power check', '2022-02-26', 'power check', 'power change,new lens', '1000', '2022-02-27', 'Ram'),
(6, 'CITZ90757146', 'maya', 'Female', '1999-02-12', '23', '8945678765', 'A+', 'Welcare', 'Ram', 'power check', '2022-02-26', 'power check', 'power change,new lens', '500', '2022-02-25', 'Ram'),
(7, 'CITZ87888308', 'sanoop', 'Male', '1998-03-04', '24', '9087656545', 'O+', 'Welcare', 'alex', '', '2022-02-26', 'ear pain with head pain', 'rdfhgsjh gvhjggbj', '350', '2022-02-05', 'alex');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `hid` int(11) NOT NULL AUTO_INCREMENT,
  `hostid` text,
  `hname` text,
  `cntn1` text,
  `cntn2` text,
  `location` text,
  `addr` text,
  `waddr` text,
  `email` text,
  `special` text,
  `licen` text,
  `seplty` text,
  `typ` text,
  `jdate` text,
  `photo1` text,
  `photo2` text,
  `photo3` text,
  `exp` text,
  `username` text,
  `password` text,
  `stat` text,
  `utyp` text,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hid`, `hostid`, `hname`, `cntn1`, `cntn2`, `location`, `addr`, `waddr`, `email`, `special`, `licen`, `seplty`, `typ`, `jdate`, `photo1`, `photo2`, `photo3`, `exp`, `username`, `password`, `stat`, `utyp`) VALUES
(1, 'MDCHP86954128', 'Welcare', '8590505701', '8590505702', 'Palakkad', 'near mercy collge, palakkad', 'http://welcare.com', 'welcare@gmail.com', 'MultiSpeciality', 'HD10201', 'Multi Speciality', 'General Medical and Surgical Hospital', '2022-02-17', 'team-3.jpg', 'c1.jpg', 'team-4.jpg', 'since 1990', 'welcare', 'welcare123', 'active', 'hospital'),
(2, 'MDCHP31816383', 'Trinity', '9895678091', '9895678092', 'palakkad', 'near shiva temple, palakkad, kerala-678001', 'http://trinity.com', 'trinity@gmail.com', 'eyespeciality', 'HD10201', 'Multi Speciality', 'General Medical and Surgical Hospital', '2022-02-17', 'c2.jpg', 'c1.jpg', 't1.jpg', 'since 1990', 'trinity', 'trinity123', 'active', 'hospital');

-- --------------------------------------------------------

--
-- Table structure for table `hospitalamount`
--

CREATE TABLE IF NOT EXISTS `hospitalamount` (
  `hospid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `hdname` text,
  `docname` text,
  `diseas` text,
  `cdate` text,
  `diseasdesc` text,
  `prescriptn` text,
  `amount` text,
  `date` date DEFAULT NULL,
  `hospital` text,
  PRIMARY KEY (`hospid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hospitalamount`
--

INSERT INTO `hospitalamount` (`hospid`, `mdcpatid`, `name`, `sex`, `dob`, `age`, `cont1`, `blgrp`, `hdname`, `docname`, `diseas`, `cdate`, `diseasdesc`, `prescriptn`, `amount`, `date`, `hospital`) VALUES
(1, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'Ram', 'viral fever', '2022-02-17', 'fever at 100degree celsius', 'paracetamol-1 0 1', '200', '2022-02-18', 'Trinity'),
(2, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'Ram', 'viral fever', '2022-02-17', 'fever at 100degree celsius', 'paracetamol-1 0 1', '200', '2022-02-16', 'Trinity'),
(3, 'CITZ81541908', 'rahul', 'Male', '2001-12-10', '21', '9037878736', 'O+', 'Welcare', 'Athira', 'red eye', '2022-02-26', 'red eye', 'eye drop', '1000', '2022-02-26', 'Welcare'),
(4, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'alex', 'sgsdg', '2022-02-27', 'sgdsd', 'sdg', '2500', '2022-02-08', 'Trinity');

-- --------------------------------------------------------

--
-- Table structure for table `laboratory`
--

CREATE TABLE IF NOT EXISTS `laboratory` (
  `lbid` int(11) NOT NULL AUTO_INCREMENT,
  `mdclbid` text,
  `name` text,
  `cntn1` text,
  `cntn2` text,
  `locatn` text,
  `addr` text,
  `email` text,
  `typ` text,
  `splty` text,
  `jdate` text,
  `photo1` text,
  `licen` text,
  `photo2` text,
  `expr` text,
  `username` text,
  `password` text,
  `stat` text,
  `utyp` text,
  PRIMARY KEY (`lbid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `laboratory`
--

INSERT INTO `laboratory` (`lbid`, `mdclbid`, `name`, `cntn1`, `cntn2`, `locatn`, `addr`, `email`, `typ`, `splty`, `jdate`, `photo1`, `licen`, `photo2`, `expr`, `username`, `password`, `stat`, `utyp`) VALUES
(1, 'MDCLB721937429', 'DN', '9087896980', '9087896981', 'palakkad', 'near arcade\r\n\r\n\r\n\r\n\r\n', 'dnlab@gmail.com', 'Clinical', 'Micro biology', '2022-02-17', 'c1.jpg', 'LD5060', 'banner44.jpg', 'since 1990', 'dnlab456', 'dnlab456', 'active', 'laboratory'),
(2, 'MDCLB1098639621', 'Lifecare', '9089657890', '9089657891', 'koppam', 'near palakkad fort.', 'lifecare@gmail.com', 'Clinical', 'Micro biology', '2022-02-17', 'banner2.jpg', 'LC50607', 'c1.jpg', 'since 2001', 'lifecare', 'lifecare', 'active', 'laboratory');

-- --------------------------------------------------------

--
-- Table structure for table `laboratoryamount`
--

CREATE TABLE IF NOT EXISTS `laboratoryamount` (
  `laboratryid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `hdname` text,
  `docname` text,
  `diseas` text,
  `cdate` text,
  `diseasdesc` text,
  `prescriptn` text,
  `photo1` text,
  `photo2` text,
  `amount` text,
  `date` text,
  `lab` text,
  PRIMARY KEY (`laboratryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `laboratoryamount`
--

INSERT INTO `laboratoryamount` (`laboratryid`, `mdcpatid`, `name`, `sex`, `dob`, `age`, `cont1`, `blgrp`, `hdname`, `docname`, `diseas`, `cdate`, `diseasdesc`, `prescriptn`, `photo1`, `photo2`, `amount`, `date`, `lab`) VALUES
(1, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'alex', 'cold', '2022-02-17', 'sss', 'dsgsdg', 'banner44.jpg', 'banner4.jpg', '250', '2022-02-19', 'DN'),
(2, 'CITZ87888308', 'sanoop', 'Male', '1998-03-04', '24', '9087656545', 'O+', 'Welcare', 'alex', '', '2022-02-26', 'ear pain with head pain', 'rdfhgsjh gvhjggbj', 'banner44.jpg', 'banner44.jpg', '500', '2022-02-18', 'DN');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `msgid` int(11) NOT NULL AUTO_INCREMENT,
  `mhostid` text,
  `hname` text,
  `cntn1` text,
  `email` text,
  `subj` text,
  `dat` text,
  `reply` text,
  `rdate` text,
  PRIMARY KEY (`msgid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`msgid`, `mhostid`, `hname`, `cntn1`, `email`, `subj`, `dat`, `reply`, `rdate`) VALUES
(1, 'MDCPH541168969', 'PriyaMedicals', '9995554121', 'priyamedhub@gmail.com', 'Hello abc', '17-02-2022', 'Hello priyamedicals.', '17-02-2022');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `mrs` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `qul` text,
  `addr` text,
  `cont1` text,
  `cont2` text,
  `email` text,
  `district` text,
  `thaluk` text,
  `panchayath` text,
  `ward` text,
  `jdate` text,
  `blgrp` text,
  `aadharno` text,
  `photo` text,
  `descp` text,
  `hdname` text,
  PRIMARY KEY (`patid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patid`, `mdcpatid`, `mrs`, `name`, `sex`, `dob`, `age`, `qul`, `addr`, `cont1`, `cont2`, `email`, `district`, `thaluk`, `panchayath`, `ward`, `jdate`, `blgrp`, `aadharno`, `photo`, `descp`, `hdname`) VALUES
(1, '1', 'Mr', 'rajiv', 'Male', '1995-10-19', '27', '12th', 'koppam', '9876543210', '8899109901', 'rajiv@gmail.com', 'palakkad', 'palakkad', 'kannadi', '14', '2022-02-17', 'O+', 'Raghavan', 'team-1.jpg', 'Infected by fever.', 'Trinity'),
(2, 'CITZ48706969', 'Mr', 'abc', 'Male', '2022-02-02', '25', '+2', 'palakkad', '6764646464', '9794646464', 'ab@gmail.com', 'palakkad', 'palakkad', 'kannadi', '3', '2022-02-17', 'O-', 'abc', 'c1.jpg', 'sss', 'Welcare'),
(3, 'CITZ81541908', 'Mr', 'rahul', 'Male', '2001-12-10', '21', '12th', 'Mercy', '9037878736', '8943767879', 'rahul@gmail.com', 'palakkad', 'palakkad', 'kannadi', '14', '2022-02-26', 'O+', 'Jairam', 'g3.jpg', 'Hai.', 'Welcare'),
(4, 'CITZ90757146', 'Mrs', 'maya', 'Female', '1999-02-12', '23', 'pg', 'near polytechnic college ', '8945678765', '9037878746', 'maya2@gmail.com', 'thrissur', 'thrissur', 'kurukanchery', '23', '2022-02-26', 'A+', 'mohanan', 'c1.jpg', 'hloo', 'Welcare'),
(5, 'CITZ87888308', 'Mr', 'sanoop', 'Male', '1998-03-04', '24', 'pg', 'near kottai', '9087656545', '8975646787', 'sanoop7@gmail.com', 'palakkad', 'palakkad', 'kannadi', '4', '2022-02-26', 'O+', 'manju', 'c3.jpg', 'hloo', 'Welcare');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE IF NOT EXISTS `pharmacy` (
  `phid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcphid` text,
  `name` text,
  `cntn1` text,
  `cntn2` text,
  `locatn` text,
  `addr` text,
  `email` text,
  `typ` text,
  `splty` text,
  `jdate` text,
  `photo1` text,
  `licen` text,
  `photo2` text,
  `expr` text,
  `username` text,
  `password` text,
  `stat` text,
  `utyp` text,
  PRIMARY KEY (`phid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`phid`, `mdcphid`, `name`, `cntn1`, `cntn2`, `locatn`, `addr`, `email`, `typ`, `splty`, `jdate`, `photo1`, `licen`, `photo2`, `expr`, `username`, `password`, `stat`, `utyp`) VALUES
(1, 'MDCPH1218198384', 'AnjaliMedical', '8760406789', '8760406781', 'meparamb', 'Near petrol pump', 'Anjalimed@gmail.com', 'Community pharmacy', 'Optum', '2022-02-17', 'c1.jpg', 'AM10203', 'c2.jpg', 'since 1998', 'anjalimed', 'anjalimed', 'active', 'pharmacy'),
(2, 'MDCPH541168969', 'PriyaMedicals', '9995554121', '9995541222', 'Sulthanpet', 'Near Petrol Pump\r\n\r\n', 'priyamedhub@gmail.com', 'Retail pharmacy', 'Accerdo', '2022-02-17', 'banner44.jpg', 'PH009876453', 'banner1.jpg', 'Since 2010\r\n', 'priyamed', 'priyamed', 'active', 'pharmacy');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacyamount`
--

CREATE TABLE IF NOT EXISTS `pharmacyamount` (
  `pharmacyid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `hdname` text,
  `docname` text,
  `diseas` text,
  `cdate` text,
  `diseasdesc` text,
  `prescriptn` text,
  `amount` text,
  `date` text,
  `pharmacy` text,
  PRIMARY KEY (`pharmacyid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pharmacyamount`
--

INSERT INTO `pharmacyamount` (`pharmacyid`, `mdcpatid`, `name`, `sex`, `dob`, `age`, `cont1`, `blgrp`, `hdname`, `docname`, `diseas`, `cdate`, `diseasdesc`, `prescriptn`, `amount`, `date`, `pharmacy`) VALUES
(1, 'CITZ48706969', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'Welcare', 'alex', 'cold', '2022-02-17', 'sss', 'dsgsdg', '2333', '2009-09-07', 'PriyaMedicals');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `prscid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `mrs` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `aadharno` text,
  `addr` text,
  `district` text,
  `thaluk` text,
  `panchayath` text,
  `ward` text,
  `hdname` text,
  `docname` text,
  `diseas` text,
  `cdate` date DEFAULT NULL,
  `diseasdesc` text,
  `prescriptn` text,
  `lbtestdescp` text,
  `pstatus` varchar(200) NOT NULL,
  PRIMARY KEY (`prscid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`prscid`, `mdcpatid`, `mrs`, `name`, `sex`, `dob`, `age`, `cont1`, `blgrp`, `aadharno`, `addr`, `district`, `thaluk`, `panchayath`, `ward`, `hdname`, `docname`, `diseas`, `cdate`, `diseasdesc`, `prescriptn`, `lbtestdescp`, `pstatus`) VALUES
(1, 'CITZ48706969', 'Mr', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'abc', 'palakkad', 'palakkad', 'palakkad', 'kannadi', '3', 'Welcare', 'alex', 'cold', '2022-02-17', 'sss', 'dsgsdg', 'sdg', 'accept'),
(2, 'CITZ48706969', 'Mr', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'abc', 'palakkad', 'palakkad', 'palakkad', 'kannadi', '3', 'Welcare', 'Ram', 'viral fever', '2022-02-17', 'fever at 100degree celsius', 'paracetamol-1 0 1', 'urine test', 'accept'),
(3, 'CITZ81541908', 'Mr', 'rahul', 'Male', '2001-12-10', '21', '9037878736', 'O+', 'Jairam', 'Mercy', 'palakkad', 'palakkad', 'kannadi', '14', 'Welcare', 'Athira', 'red eye', '2022-02-26', 'red eye', 'eye drop', 'Eye test', ''),
(4, 'CITZ81541908', 'Mr', 'rahul', 'Male', '2001-12-10', '21', '9037878736', 'O+', 'Jairam', 'Mercy', 'palakkad', 'palakkad', 'kannadi', '14', 'Welcare', 'Athira', 'red eye', '2022-02-26', 'infected by red eye', 'eye drop', 'eye test', ''),
(5, 'CITZ90757146', 'Mrs', 'maya', 'Female', '1999-02-12', '23', '8945678765', 'A+', 'mohanan', 'near polytechnic college ', 'thrissur', 'thrissur', 'kurukanchery', '23', 'Welcare', 'Ram', 'power check', '2022-02-26', 'power check', 'power change,new lens', 'manual', ''),
(6, 'CITZ87888308', 'Mr', 'sanoop', 'Male', '1998-03-04', '24', '9087656545', 'O+', 'manju', 'near kottai', 'palakkad', 'palakkad', 'kannadi', '4', 'Welcare', 'alex', '', '2022-02-26', 'ear pain with head pain', 'rdfhgsjh gvhjggbj', 'fsg fswbhh', ''),
(7, 'CITZ48706969', 'Mr', 'abc', 'Male', '2022-02-02', '25', '6764646464', 'O-', 'abc', 'palakkad', 'palakkad', 'palakkad', 'kannadi', '3', 'Welcare', 'alex', 'sgsdg', '2022-02-27', 'sgdsd', 'sdg', 'sdg', 'accept');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE IF NOT EXISTS `rooms` (
  `rms_id` int(11) NOT NULL AUTO_INCREMENT,
  `hostid` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `roomno` varchar(200) NOT NULL,
  `floor` varchar(200) NOT NULL,
  `cont` varchar(200) NOT NULL,
  `des` text NOT NULL,
  `rate` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `hname` varchar(200) NOT NULL,
  PRIMARY KEY (`rms_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`rms_id`, `hostid`, `name`, `type`, `roomno`, `floor`, `cont`, `des`, `rate`, `date`, `hname`) VALUES
(1, 'MDCHP86954128', 'RICE', 'Ac', '101', 'SECOND', '9847169044', 'NICE', '205', '2022-04-13', 'Welcare'),
(2, 'MDCHP86954128', 'RICE', 'Ac', '101', 'SECOND', '9847169044', 'NICE', '205', '2022-04-13', 'Welcare');

-- --------------------------------------------------------

--
-- Table structure for table `roomsbooking`
--

CREATE TABLE IF NOT EXISTS `roomsbooking` (
  `hbkid` int(11) NOT NULL AUTO_INCREMENT,
  `mdcpatid` text,
  `pname` text,
  `age` text,
  `sex` text,
  `pcont1` text,
  `dat` text,
  `tm` text,
  `bkid` text,
  `bkname` text,
  `hcntn1` text,
  `date` text,
  `diseases` text,
  `descrp` text,
  `stat` text,
  `type` varchar(200) NOT NULL,
  `roomno` varchar(200) NOT NULL,
  `rate` varchar(200) NOT NULL,
  PRIMARY KEY (`hbkid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `roomsbooking`
--

INSERT INTO `roomsbooking` (`hbkid`, `mdcpatid`, `pname`, `age`, `sex`, `pcont1`, `dat`, `tm`, `bkid`, `bkname`, `hcntn1`, `date`, `diseases`, `descrp`, `stat`, `type`, `roomno`, `rate`) VALUES
(9, '1', 'rajiv', '27', 'Male', '9876543210', '2022-04-13', '11:11', 'MDCHP86954128', 'Welcare', '9847169044', '13-04-2022', 'ss', 'sss', 'Accept', 'Ac', '101', '205'),
(10, '1', 'rajiv', '27', 'Male', '9876543210', '2022-04-13', '11:11', 'MDCHP86954128', 'Welcare', '9847169044', '13-04-2022', 'ss', 'sss', 'pending', 'Ac', '101', '205');

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE IF NOT EXISTS `vaccine` (
  `vacid` int(11) NOT NULL AUTO_INCREMENT,
  `photo` text NOT NULL,
  `mdcpatid` text,
  `mrs` text,
  `name` text,
  `sex` text,
  `dob` text,
  `age` text,
  `cont1` text,
  `blgrp` text,
  `aadharno` text,
  `addr` text,
  `district` text,
  `thaluk` text,
  `panchayath` text,
  `ward` text,
  `hdname` text,
  `docname` text,
  `vaccine` text,
  `descr` text,
  `cert` text,
  `date` text,
  `diseas` text,
  `cdate` text,
  PRIMARY KEY (`vacid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
